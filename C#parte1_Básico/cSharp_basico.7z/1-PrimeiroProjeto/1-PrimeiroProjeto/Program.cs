﻿using System;

namespace _1_PrimeiroProjeto
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            Console.WriteLine(" A execução acabou, tecle entrar para continuar...");
            Console.ReadLine();
        }
    }
}
