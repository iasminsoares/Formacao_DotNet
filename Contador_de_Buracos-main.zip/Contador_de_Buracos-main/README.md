# Contador_de_Buracos

Teste realizado no processo seletivo da empresa HMB - Cógido em C# 


